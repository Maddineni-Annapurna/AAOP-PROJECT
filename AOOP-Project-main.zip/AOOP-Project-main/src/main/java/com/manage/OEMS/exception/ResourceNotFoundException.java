package com.manage.OEMS.exception;



@SuppressWarnings("serial")
public class ResourceNotFoundException extends Exception {
	
	 public ResourceNotFoundException(String message){
	        super(message);
	    }

}
